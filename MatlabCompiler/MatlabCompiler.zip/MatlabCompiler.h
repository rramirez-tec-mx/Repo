#pragma once
#include <Windows.h>
#include <yvals.h>
#if (_MSC_VER >= 1600)
#define __STDC_UTF_16__
#endif

#define DLL_EXPORT __declspec(dllexport)

class DLL_EXPORT CMatlabCompiler
{
public:
	CMatlabCompiler(void);
	~CMatlabCompiler(void);

	double Do(double ingresso);
};




